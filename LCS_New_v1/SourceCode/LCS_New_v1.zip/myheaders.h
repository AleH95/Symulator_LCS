#ifndef MYHEADERS_H
#define MYHEADERS_H

#include "macros.h"
#include <QWidget>
#include <QGridLayout>
#include <QPushButton>
#include <QSignalMapper>
#include <QString>
#include <QThread>
#include <QtCore>
#include <QLabel>
#include <QHBoxLayout>
#include <QThread>

#endif // MYHEADERS_H
