# Symulator_LCS
Symulator sterowania urzadzeniami stacyjnymi/posterunkowymi

Podzial pracy:
1) Przyciski - oprogramowanie i wisualizacja
    - Hebda Aleksander
    - Baryczka Maksymilian    
2) Wisualizacja torow
    - Dyja Christopher
    - Bysiel Rafal
