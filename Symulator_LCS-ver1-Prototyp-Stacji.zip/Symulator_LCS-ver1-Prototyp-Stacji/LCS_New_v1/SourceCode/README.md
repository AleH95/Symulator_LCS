# Symulator_LCS
Symulator sterowania urzadzeniami stacyjnymi/posterunkowymi

Podzial pracy:
1) Oprogramowanie i wisualizacja
    - Dyja Christopher
    - Hebda Aleksander
2) Wisualizacja torow
    - Sasko Kuba
3) Pozostale funkcjonalnosci
    - Baryczka Maksymilian
    - Bysiek Rafal
    
